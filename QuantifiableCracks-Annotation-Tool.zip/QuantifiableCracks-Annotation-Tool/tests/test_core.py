import importlib.util
import sys
import unittest
from pathlib import Path

import cv2
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "annotate_crack_masks", ROOT / "annotate_crack_masks.py"
)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class AnnotationCoreTests(unittest.TestCase):
    def test_metric_homography_maps_marker_corners(self):
        corners = np.array(
            [[10.0, 20.0], [50.0, 20.0], [50.0, 60.0], [10.0, 60.0]],
            dtype=np.float32,
        )
        transform = MODULE.image_to_metric_homography(corners, 20.0)
        mapped = cv2.perspectiveTransform(corners.reshape(1, 4, 2), transform)[0]
        expected = np.array(
            [[0.0, 0.0], [20.0, 0.0], [20.0, 20.0], [0.0, 20.0]],
            dtype=np.float32,
        )
        np.testing.assert_allclose(mapped, expected, atol=1e-4)

    def test_automatic_proposal_follows_central_dark_ridge(self):
        image = np.full((256, 256, 3), 210, dtype=np.uint8)
        cv2.line(image, (128, 20), (128, 235), (25, 25, 25), 5)
        proposal = MODULE.automatic_proposal(image)
        self.assertGreater(np.count_nonzero(proposal), 500)
        self.assertGreater(np.count_nonzero(proposal[:, 124:133]), 500)

    def test_tiny_components_are_removed(self):
        mask = np.zeros((64, 64), dtype=np.uint8)
        mask[2:4, 2:4] = 255
        mask[20:30, 20:30] = 255
        cleaned = MODULE.remove_tiny_components(mask, minimum_area=8)
        self.assertEqual(int(cleaned[2, 2]), 0)
        self.assertEqual(int(cleaned[25, 25]), 255)


if __name__ == "__main__":
    unittest.main()

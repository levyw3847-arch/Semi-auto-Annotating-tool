# QuantifiableCracks 裂缝标注工具

这是一个用于标定图像中裂缝像素级掩膜制作的桌面工具。程序先利用相机内参消除镜头畸变，再通过ArUco刚性标志建立毫米坐标，然后提取固定物理尺寸的ROI并生成自动掩膜建议，最后由标注者人工校正。

## 主要功能

- 直接运行 `annotate_crack_masks.py` 后显示配置窗口。
- 可分别选择图片文件夹、相机标定NPZ、ArUco角点JSON和输出文件夹。
- 在表面与标志近似共面的前提下，生成统一毫米尺度的ROI。
- 点击裂缝中心后自动生成暗纹掩膜建议。
- 支持添加、擦除、撤销、缩放、调整ROI和重新选择中心。
- 每完成一张图自动保存进度，可中断后继续。
- 同时输出ROI掩膜、原图尺寸掩膜、叠加图和坐标变换信息。

## 使用前提

裂缝表面应当近似为平面，ArUco标志应与裂缝近似共面。拍摄裂缝时必须保持与相机内参标定时相同的相机和镜头配置。

自动掩膜只是标注建议，不是无人审核的真值。每张保存的掩膜都应经过人工检查。

## 安装

建议使用Python 3.10或更高版本。

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python annotate_crack_masks.py
```

Windows也可以双击 `run_annotator.bat` 启动。

## 工作流程

1. 使用 `calibrate_camera.py` 和棋盘格照片计算相机内参与畸变系数。
2. 使用 `annotate_aruco.py` 自动识别ArUco ID 0，并人工修正识别失败的图片。
3. 运行 `annotate_crack_masks.py`，在配置窗口中选择图片、标定文件、角点文件和输出位置。
4. 在原图中点击目标裂缝中心，在ROI视图中修正红色掩膜，然后按 `Enter` 保存。

完整命令和参数示例见 [README.md](README.md)。

## 标注快捷键

| 按键或鼠标 | 功能 |
|---|---|
| 原图中左键 | 选择裂缝中心 |
| ROI中左键拖动 | 添加裂缝像素 |
| ROI中右键拖动 | 擦除像素 |
| 鼠标滚轮 | 缩放 |
| `A` | 恢复自动掩膜建议 |
| `C` | 清空掩膜 |
| `Z` | 撤销 |
| `[` / `]` | 减小/增大画笔 |
| `E` / `D` | 扩大/缩小ROI |
| `B` | 返回原图重新选择中心 |
| `Enter` | 保存并进入下一张 |
| `N` | 跳过 |
| `Esc` / `Q` | 保存进度并退出 |

## 输出

```text
annotations/
|-- annotation_progress.json
|-- roi_images/
|-- roi_masks/
|-- roi_overlays/
|-- full_masks/
`-- full_overlays/
```

掩膜中背景像素值为 `0`，裂缝像素值为 `255`。程序会检查输出文件夹中的历史进度，防止将不同图片文件夹的标注记录混在一起。

## 许可证

代码使用MIT License，详见 [LICENSE](LICENSE)。

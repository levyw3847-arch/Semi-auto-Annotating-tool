@echo off
setlocal
python annotate_crack_masks.py
if errorlevel 1 pause
endlocal
